import React, { Component } from 'react';
import './LogIn.css'

class LogIn extends Component {
    render() {
        return (
          <div className="loginDiv">
            <form className="login" action="/logincheck" method="POST">
                <input type="email" name="email" placeholder="email"/>
                <br/>
                <input type="password" name="pass" placeholder="password"/>
                <br/>
                <button
                  id="enter"
                  type="submit"
                  name="button"
                  className="loginButton">Login</button>
            </form>

            <div id="mission">
              <p>Hi there! At Krusty Krab Pizza, we aim to make your life easier when it comes to grabbing a slice of pizza.Hi there! At Krusty Krab Pizza, we aim to make your life easier when it comes to grabbing a slice of pizza.Hi there! At Krusty Krab Pizza, we aim to make your life easier when it comes to grabbing a slice of pizza.Hi there! At Krusty Krab Pizza, we aim to make your life easier when it comes to grabbing a slice of pizza.Hi there! At Krusty Krab Pizza, we aim to make your life easier when it comes to grabbing a slice of pizza.</p>
            </div>
          </div>
      )
    }
}

export default LogIn;

import React, { Component } from 'react';
import { Route, Link } from 'react-router-dom';
import './Routes.css';

import Register from '../Register/Register.js';
import LogIn from '../LogIn/LogIn.js';

class Routes extends Component {
    render () {
        return (
            <div>
              <header className='Routes'>
                    <nav>
                      <ul>
                          <li><Link to="/register">Register</Link></li>
                          <li><Link to="/login">Login</Link></li>
                      </ul>
                  </nav>
              </header>

              <Route path="/register" exact component={ Register } />
              <Route path="/login" exact component={ LogIn } />
            </div>
        );
    }
}

export default Routes;
